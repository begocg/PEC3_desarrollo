const app = new TodoController(new TodoService(), new TodoView());
